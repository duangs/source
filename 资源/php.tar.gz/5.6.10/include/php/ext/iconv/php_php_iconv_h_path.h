#define PHP_ICONV_H_PATH </usr/local/libiconv/include/iconv.h>
